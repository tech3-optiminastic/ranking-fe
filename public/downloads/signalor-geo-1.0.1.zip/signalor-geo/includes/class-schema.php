<?php
/**
 * Signalor Schema + Meta — renders JSON-LD, canonical, viewport, AI meta, and SEO fallback via wp_head.
 * Handles conflicts with Yoast, RankMath, and AIOSEO.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Signalor_Schema {

    /**
     * Hooked to wp_head — outputs JSON-LD + meta tags for current post.
     */
    public static function render() {

        if ( is_singular() ) {
            $post_id = get_the_ID();
            if ( ! $post_id ) return;

            // ── JSON-LD Schema ───────────────────────────────────────
            $schema = get_post_meta( $post_id, '_signalor_schema', true );
            if ( ! empty( $schema ) ) {
                $decoded = json_decode( $schema );
                if ( json_last_error() === JSON_ERROR_NONE ) {
                    // Disable competing schema from SEO plugins
                    $disable_seo = get_post_meta( $post_id, '_signalor_disable_seo_schema', true );
                    if ( $disable_seo === 'yes' ) {
                        // Yoast: disable its JSON-LD output
                        add_filter( 'wpseo_json_ld_output', '__return_empty_array' );
                        // RankMath: disable its JSON-LD output
                        add_filter( 'rank_math/json_ld', '__return_empty_array' );
                    }

                    echo "\n<!-- Signalor GEO Schema -->\n";
                    echo '<script type="application/ld+json">' . "\n";
                    echo wp_json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
                    echo "\n</script>\n";
                }
            }

            // ── Canonical tag ────────────────────────────────────────
            $canonical = get_post_meta( $post_id, '_signalor_canonical', true );
            if ( ! empty( $canonical ) ) {
                // Remove WordPress core canonical to avoid duplicates
                remove_action( 'wp_head', 'rel_canonical' );
                // Remove Yoast canonical
                add_filter( 'wpseo_canonical', '__return_false' );
                // Remove RankMath canonical
                add_filter( 'rank_math/frontend/canonical', '__return_false' );

                echo '<link rel="canonical" href="' . esc_url( $canonical ) . '" />' . "\n";
            }

            // ── Noindex removal — force index (only when no SEO plugin) ──
            $force_index = get_post_meta( $post_id, '_signalor_force_index', true );
            if ( $force_index === 'yes' ) {
                echo '<meta name="robots" content="index, follow" />' . "\n";
            }

            // ── AI crawler meta tags ─────────────────────────────────
            $ai_meta = get_post_meta( $post_id, '_signalor_ai_meta', true );
            if ( $ai_meta === 'yes' ) {
                $bots = [ 'GPTBot', 'Google-Extended', 'anthropic-ai', 'ClaudeBot', 'PerplexityBot', 'ChatGPT-User', 'CCBot' ];
                echo "<!-- Signalor GEO AI Meta -->\n";
                foreach ( $bots as $bot ) {
                    echo '<meta name="' . esc_attr( $bot ) . '" content="index, follow" />' . "\n";
                }
            }

            // ── SEO meta fallback (when no SEO plugin installed) ─────
            if ( ! defined( 'WPSEO_VERSION' ) && ! class_exists( 'RankMath' ) && ! function_exists( 'aioseo' ) ) {
                $seo_title = get_post_meta( $post_id, '_signalor_seo_title', true );
                $seo_desc  = get_post_meta( $post_id, '_signalor_seo_description', true );
                if ( ! empty( $seo_desc ) ) {
                    echo '<meta name="description" content="' . esc_attr( $seo_desc ) . '" />' . "\n";
                }
                // Title override via wp_title filter is handled below
            }
        }

        // ── Site-wide: Viewport (only if not already in theme) ───────
        $viewport = get_option( 'signalor_viewport', '' );
        if ( ! empty( $viewport ) ) {
            // Remove WordPress core viewport for block themes to avoid duplicate
            remove_action( 'wp_head', '_block_template_viewport_meta_tag', 0 );
            echo '<meta name="viewport" content="' . esc_attr( $viewport ) . '" />' . "\n";
        }
    }

    /**
     * Filter wp_title for SEO title override (when no SEO plugin).
     */
    public static function filter_title( $title ) {
        if ( ! is_singular() ) return $title;
        if ( defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || function_exists( 'aioseo' ) ) return $title;

        $post_id = get_the_ID();
        if ( ! $post_id ) return $title;

        $seo_title = get_post_meta( $post_id, '_signalor_seo_title', true );
        if ( ! empty( $seo_title ) ) return $seo_title;

        return $title;
    }
}
