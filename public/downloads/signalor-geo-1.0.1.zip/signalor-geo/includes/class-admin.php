<?php
/**
 * Signalor Admin Page — shows API key + connection status.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Signalor_Admin {

    public static function register() {
        add_action( 'admin_menu', [ __CLASS__, 'add_menu' ] );
    }

    public static function add_menu() {
        add_options_page(
            'Signalor GEO',
            'Signalor GEO',
            'manage_options',
            'signalor-geo',
            [ __CLASS__, 'render_page' ]
        );
    }

    public static function render_page() {
        $api_key = get_option( 'signalor_api_key', '' );
        $site_url = get_bloginfo( 'url' );
        $site_name = get_bloginfo( 'name' );
        ?>
        <div class="wrap">
            <h1>Signalor GEO</h1>
            <p>Connect your WordPress site to <a href="https://signalor.ai" target="_blank">Signalor.ai</a> for AI visibility optimization.</p>

            <div class="card" style="max-width: 600px; padding: 20px; margin-top: 20px;">
                <h2 style="margin-top: 0;">Connection Details</h2>
                <p>Copy these into your Signalor dashboard → Settings → Integrations → WordPress:</p>

                <table class="form-table">
                    <tr>
                        <th>Site URL</th>
                        <td>
                            <input type="text" value="<?php echo esc_attr( $site_url ); ?>" readonly class="regular-text" id="signalor-site-url" style="background: #f0f0f0;">
                            <button type="button" class="button" onclick="copyField('signalor-site-url')">Copy</button>
                        </td>
                    </tr>
                    <tr>
                        <th>API Key</th>
                        <td>
                            <input type="text" value="<?php echo esc_attr( $api_key ); ?>" readonly class="regular-text" id="signalor-api-key" style="background: #f0f0f0; font-family: monospace;">
                            <button type="button" class="button" onclick="copyField('signalor-api-key')">Copy</button>
                        </td>
                    </tr>
                </table>

                <p class="description" style="margin-top: 15px;">
                    <strong>How to connect:</strong><br>
                    1. Go to <a href="https://signalor.ai" target="_blank">signalor.ai</a> → Dashboard → Settings → Integrations<br>
                    2. Click "Connect WordPress"<br>
                    3. Paste your Site URL and API Key<br>
                    4. Click Connect — done!
                </p>
            </div>

            <div class="card" style="max-width: 600px; padding: 20px; margin-top: 20px;">
                <h2 style="margin-top: 0;">Plugin Status</h2>
                <table class="form-table">
                    <tr>
                        <th>Plugin Version</th>
                        <td><?php echo SIGNALOR_VERSION; ?></td>
                    </tr>
                    <tr>
                        <th>Site Name</th>
                        <td><?php echo esc_html( $site_name ); ?></td>
                    </tr>
                    <tr>
                        <th>REST API</th>
                        <td><span style="color: green;">&#10003;</span> Active at <code><?php echo esc_html( $site_url ); ?>/wp-json/signalor/v1/</code></td>
                    </tr>
                    <tr>
                        <th>llms.txt</th>
                        <td>
                            <?php
                            $llms = get_option( 'signalor_llms_txt', '' );
                            if ( $llms ) {
                                echo '<span style="color: green;">&#10003;</span> Active — <a href="' . esc_url( home_url( '/llms.txt' ) ) . '" target="_blank">View</a>';
                            } else {
                                echo '<span style="color: #999;">—</span> Not configured (will be created when you apply a fix)';
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="card" style="max-width: 600px; padding: 20px; margin-top: 20px;">
                <h2 style="margin-top: 0;">Regenerate API Key</h2>
                <p>If your key is compromised, generate a new one. You'll need to update it in your Signalor dashboard.</p>
                <form method="post">
                    <?php wp_nonce_field( 'signalor_regen_key' ); ?>
                    <input type="hidden" name="signalor_action" value="regenerate_key">
                    <button type="submit" class="button" onclick="return confirm('Regenerate API key? You will need to update it in your Signalor dashboard.');">Regenerate Key</button>
                </form>
                <?php
                if ( isset( $_POST['signalor_action'] ) && $_POST['signalor_action'] === 'regenerate_key' ) {
                    if ( check_admin_referer( 'signalor_regen_key' ) ) {
                        $new_key = wp_generate_password( 40, false );
                        update_option( 'signalor_api_key', $new_key );
                        echo '<div class="notice notice-success" style="margin-top: 10px;"><p>API key regenerated. Copy it above and update your Signalor dashboard.</p></div>';
                        echo '<script>document.getElementById("signalor-api-key").value = "' . esc_js( $new_key ) . '";</script>';
                    }
                }
                ?>
            </div>
        </div>

        <script>
        function copyField(id) {
            var field = document.getElementById(id);
            field.select();
            document.execCommand('copy');
            var btn = field.nextElementSibling;
            var original = btn.textContent;
            btn.textContent = 'Copied!';
            setTimeout(function() { btn.textContent = original; }, 2000);
        }
        </script>
        <?php
    }
}
