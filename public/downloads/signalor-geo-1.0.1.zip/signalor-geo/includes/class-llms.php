<?php
/**
 * Signalor LLMS — serves /llms.txt as a virtual plain-text page.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Signalor_LLMS {

    /**
     * Register rewrite rule for /llms.txt
     */
    public static function register_rewrite() {
        add_rewrite_rule( '^llms\.txt$', 'index.php?signalor_file=llms', 'top' );
        add_filter( 'query_vars', function ( $vars ) {
            $vars[] = 'signalor_file';
            return $vars;
        } );
    }

    /**
     * Serve llms.txt content on template_redirect.
     */
    public static function serve() {
        if ( get_query_var( 'signalor_file' ) !== 'llms' ) return;

        $content = get_option( 'signalor_llms_txt', '' );

        if ( empty( $content ) ) {
            // Generate default llms.txt from site info
            $name = get_bloginfo( 'name' );
            $desc = get_bloginfo( 'description' );
            $url  = get_bloginfo( 'url' );

            $content = "# {$name}\n\n";
            $content .= "> {$desc}\n\n";
            $content .= "## About\n";
            $content .= "Website: {$url}\n\n";
            $content .= "## Pages\n";

            // List published pages
            $pages = get_pages( [ 'post_status' => 'publish', 'number' => 20 ] );
            foreach ( $pages as $page ) {
                $content .= "- [{$page->post_title}](" . get_permalink( $page->ID ) . ")\n";
            }

            // List recent posts
            $posts = get_posts( [ 'post_status' => 'publish', 'numberposts' => 10 ] );
            if ( $posts ) {
                $content .= "\n## Recent Posts\n";
                foreach ( $posts as $post ) {
                    $content .= "- [{$post->post_title}](" . get_permalink( $post->ID ) . ")\n";
                }
            }
        }

        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'Cache-Control: public, max-age=3600' );
        header( 'X-Robots-Tag: noindex' );
        echo $content;
        exit;
    }
}
