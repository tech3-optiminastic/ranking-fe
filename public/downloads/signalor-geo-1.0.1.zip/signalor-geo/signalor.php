<?php
/**
 * Plugin Name: Signalor GEO
 * Plugin URI:  https://signalor.ai/wordpress
 * Description: Receive and apply GEO optimization fixes from Signalor.ai — schema, content, SEO meta, and llms.txt.
 * Version:     1.0.1
 * Author:      Signalor
 * Author URI:  https://signalor.ai
 * License:     GPL-2.0-or-later
 * Text Domain: signalor-geo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIGNALOR_VERSION', '1.0.1' );
define( 'SIGNALOR_PATH', plugin_dir_path( __FILE__ ) );

// Always allow clean deactivation even when the install is broken.
register_deactivation_hook(
	__FILE__,
	function () {
		flush_rewrite_rules();
	}
);

$signalor_required_files = [
	'includes/class-api.php',
	'includes/class-schema.php',
	'includes/class-llms.php',
	'includes/class-admin.php',
];

$signalor_missing = [];
foreach ( $signalor_required_files as $rel ) {
	if ( ! is_readable( SIGNALOR_PATH . $rel ) ) {
		$signalor_missing[] = $rel;
	}
}

if ( ! empty( $signalor_missing ) ) {
	$signalor_incomplete_notice = static function () use ( $signalor_missing ) {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$list = esc_html( implode( ', ', $signalor_missing ) );
		echo '<div class="notice notice-error"><p>';
		echo '<strong>Signalor GEO:</strong> ';
		echo esc_html__( 'Plugin files are incomplete (missing: ', 'signalor-geo' ) . $list . '). ';
		echo esc_html__( 'Deactivate and delete this plugin, then install again using the full ', 'signalor-geo' );
		echo '<code>signalor-geo.zip</code> ';
		echo esc_html__( 'from Signalor onboarding, or add the ', 'signalor-geo' );
		echo '<code>includes/</code> ';
		echo esc_html__( 'folder from ', 'signalor-geo' );
		echo '<a href="https://github.com/tech3-design/signalor-wordpress-plugin" target="_blank" rel="noopener">GitHub</a>.';
		echo '</p></div>';
	};
	add_action( 'admin_notices', $signalor_incomplete_notice );
	add_action( 'network_admin_notices', $signalor_incomplete_notice );
	// Do not fatal — admin stays usable so the plugin can be removed or fixed.
	return;
}

// Core classes
require_once SIGNALOR_PATH . 'includes/class-api.php';
require_once SIGNALOR_PATH . 'includes/class-schema.php';
require_once SIGNALOR_PATH . 'includes/class-llms.php';
require_once SIGNALOR_PATH . 'includes/class-admin.php';

// Boot
add_action( 'rest_api_init', [ 'Signalor_API', 'register_routes' ] );
Signalor_Admin::register();
add_action( 'wp_head', [ 'Signalor_Schema', 'render' ] );
add_action( 'init', [ 'Signalor_LLMS', 'register_rewrite' ] );
add_action( 'template_redirect', [ 'Signalor_LLMS', 'serve' ] );

// SEO title filter (fallback when no SEO plugin installed)
add_filter( 'wp_title', [ 'Signalor_Schema', 'filter_title' ] );
add_filter( 'pre_get_document_title', [ 'Signalor_Schema', 'filter_title' ] );

// Prevent trailing slash redirect on /llms.txt
add_filter(
	'redirect_canonical',
	function ( $redirect_url, $requested_url ) {
		if ( preg_match( '/\/llms\.txt\/?$/', $requested_url ) ) {
			return false;
		}
		return $redirect_url;
	},
	10,
	2
);

// robots.txt filter — allow AI bots
add_filter(
	'robots_txt',
	function ( $output, $public ) {
		$custom = get_option( 'signalor_robots_txt', '' );
		if ( ! empty( $custom ) ) {
			return $output . "\n" . $custom;
		}

		$ai_bots = [ 'GPTBot', 'Google-Extended', 'anthropic-ai', 'ClaudeBot', 'PerplexityBot', 'ChatGPT-User', 'CCBot' ];
		$additions = "\n# Signalor GEO — Allow AI crawlers\n";
		foreach ( $ai_bots as $bot ) {
			if ( stripos( $output, $bot ) === false ) {
				$additions .= "User-agent: {$bot}\nAllow: /\n\n";
			}
		}
		return $output . $additions;
	},
	10,
	2
);

register_activation_hook(
	__FILE__,
	function () {
		if ( ! get_option( 'signalor_api_key' ) ) {
			update_option( 'signalor_api_key', wp_generate_password( 40, false ) );
		}
		Signalor_LLMS::register_rewrite();
		flush_rewrite_rules();
	}
);
