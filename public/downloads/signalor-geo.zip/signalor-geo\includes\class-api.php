<?php
/**
 * Signalor REST API — thin executor for GEO fixes.
 * All endpoints authenticated via X-Signalor-Key header.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Signalor_API {

    /**
     * Register all REST routes under /signalor/v1/
     */
    public static function register_routes() {
        $ns = 'signalor/v1';

        register_rest_route( $ns, '/status', [
            'methods'  => 'GET',
            'callback' => [ __CLASS__, 'status' ],
            'permission_callback' => [ __CLASS__, 'check_key' ],
        ] );

        register_rest_route( $ns, '/get-content', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'get_content' ],
            'permission_callback' => [ __CLASS__, 'check_key' ],
        ] );

        register_rest_route( $ns, '/apply-fix', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'apply_fix' ],
            'permission_callback' => [ __CLASS__, 'check_key' ],
        ] );

        register_rest_route( $ns, '/replace-text', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'replace_text' ],
            'permission_callback' => [ __CLASS__, 'check_key' ],
        ] );

        register_rest_route( $ns, '/connect', [
            'methods'  => 'GET',
            'callback' => [ __CLASS__, 'connect' ],
            'permission_callback' => function () {
                return current_user_can( 'manage_options' );
            },
        ] );
    }

    public static function check_key( $request ) {
        $key = $request->get_header( 'X-Signalor-Key' );
        $stored = get_option( 'signalor_api_key', '' );
        return $key && hash_equals( $stored, $key );
    }

    public static function status() {
        return rest_ensure_response( [
            'plugin'  => 'signalor',
            'version' => SIGNALOR_VERSION,
            'site'    => get_bloginfo( 'url' ),
            'name'    => get_bloginfo( 'name' ),
            'ok'      => true,
        ] );
    }

    public static function connect() {
        return rest_ensure_response( [
            'api_key' => get_option( 'signalor_api_key' ),
            'site'    => get_bloginfo( 'url' ),
            'name'    => get_bloginfo( 'name' ),
            'version' => SIGNALOR_VERSION,
        ] );
    }

    public static function get_content( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        return rest_ensure_response( [
            'post_id' => $post->ID,
            'title'   => $post->post_title,
            'content' => $post->post_content,
            'url'     => get_permalink( $post->ID ),
            'type'    => $post->post_type,
        ] );
    }

    public static function apply_fix( $request ) {
        $fix_type = $request->get_param( 'fix_type' );

        switch ( $fix_type ) {
            case 'content':
            case 'faq':
                return self::fix_content( $request );
            case 'schema':
                return self::fix_schema( $request );
            case 'meta':
                return self::fix_meta( $request );
            case 'llms':
                return self::fix_llms( $request );
            case 'robots':
                return self::fix_robots( $request );
            case 'canonical':
                return self::fix_canonical( $request );
            case 'viewport':
                return self::fix_viewport( $request );
            case 'noindex':
                return self::fix_noindex( $request );
            case 'ai_meta':
                return self::fix_ai_meta( $request );
            default:
                return new WP_Error( 'invalid_fix_type', 'Unknown fix_type: ' . $fix_type, [ 'status' => 400 ] );
        }
    }

    // ── Fix Handlers ─────────────────────────────────────────────────

    private static function fix_content( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        $new_content = $request->get_param( 'content' );
        if ( empty( $new_content ) ) {
            return new WP_Error( 'empty_content', 'Content cannot be empty.', [ 'status' => 400 ] );
        }

        // Backup original content before overwriting
        update_post_meta( $post->ID, '_signalor_content_backup', $post->post_content );

        // Sanitize: allow safe HTML tags
        $new_content = wp_kses_post( $new_content );

        $result = wp_update_post( [
            'ID'           => $post->ID,
            'post_content' => $new_content,
        ], true );

        if ( is_wp_error( $result ) ) return $result;

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'Content updated: "' . $post->post_title . '"',
            'post_id' => $post->ID,
            'url'     => get_permalink( $post->ID ),
            'chars'   => strlen( $new_content ),
        ] );
    }

    private static function fix_schema( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        $schema = $request->get_param( 'schema' );
        if ( empty( $schema ) ) {
            return new WP_Error( 'empty_schema', 'Schema cannot be empty.', [ 'status' => 400 ] );
        }

        $raw = preg_replace( '/<\/?script[^>]*>/i', '', $schema );
        $decoded = json_decode( trim( $raw ) );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'invalid_json', 'Schema is not valid JSON: ' . json_last_error_msg(), [ 'status' => 400 ] );
        }

        update_post_meta( $post->ID, '_signalor_schema', wp_json_encode( $decoded ) );

        // Disable competing schema from SEO plugins for this post
        update_post_meta( $post->ID, '_signalor_disable_seo_schema', 'yes' );

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'Schema injected for "' . $post->post_title . '"',
            'post_id' => $post->ID,
        ] );
    }

    private static function fix_meta( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        $title = sanitize_text_field( $request->get_param( 'seo_title' ) );
        $desc  = sanitize_text_field( $request->get_param( 'seo_description' ) );

        if ( empty( $title ) && empty( $desc ) ) {
            return new WP_Error( 'empty_meta', 'At least seo_title or seo_description is required.', [ 'status' => 400 ] );
        }

        // Detect active SEO plugin and write to correct meta keys
        if ( defined( 'WPSEO_VERSION' ) ) {
            // Yoast SEO
            if ( $title ) update_post_meta( $post->ID, '_yoast_wpseo_title', $title );
            if ( $desc )  update_post_meta( $post->ID, '_yoast_wpseo_metadesc', $desc );
        } elseif ( class_exists( 'RankMath' ) ) {
            // RankMath
            if ( $title ) update_post_meta( $post->ID, 'rank_math_title', $title );
            if ( $desc )  update_post_meta( $post->ID, 'rank_math_description', $desc );
        } elseif ( function_exists( 'aioseo' ) ) {
            // AIOSEO
            if ( $title ) update_post_meta( $post->ID, '_aioseo_title', $title );
            if ( $desc )  update_post_meta( $post->ID, '_aioseo_description', $desc );
        } else {
            // No SEO plugin — store in our own meta, rendered by class-schema.php
            if ( $title ) update_post_meta( $post->ID, '_signalor_seo_title', $title );
            if ( $desc )  update_post_meta( $post->ID, '_signalor_seo_description', $desc );
        }

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'SEO meta updated for "' . $post->post_title . '"',
            'post_id' => $post->ID,
        ] );
    }

    private static function fix_llms( $request ) {
        $content = $request->get_param( 'llms_content' );
        if ( empty( $content ) ) {
            return new WP_Error( 'empty_llms', 'llms.txt content cannot be empty.', [ 'status' => 400 ] );
        }

        update_option( 'signalor_llms_txt', $content );

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'llms.txt updated (' . strlen( $content ) . ' chars)',
            'url'     => home_url( '/llms.txt' ),
        ] );
    }

    private static function fix_robots( $request ) {
        $content = $request->get_param( 'content' );
        if ( empty( $content ) ) {
            return new WP_Error( 'empty_robots', 'robots.txt content cannot be empty.', [ 'status' => 400 ] );
        }

        // Warn if physical robots.txt exists (filter won't work)
        if ( file_exists( ABSPATH . 'robots.txt' ) ) {
            return rest_ensure_response( [
                'status'  => 'partial',
                'message' => 'Warning: A physical robots.txt file exists at site root. The WordPress filter cannot override it. Delete the file or edit it manually.',
                'url'     => home_url( '/robots.txt' ),
            ] );
        }

        update_option( 'signalor_robots_txt', $content );

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'robots.txt updated (' . strlen( $content ) . ' chars)',
            'url'     => home_url( '/robots.txt' ),
        ] );
    }

    private static function fix_canonical( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        $canonical = $request->get_param( 'canonical_url' );
        if ( empty( $canonical ) ) {
            $canonical = get_permalink( $post->ID );
        }

        update_post_meta( $post->ID, '_signalor_canonical', esc_url_raw( $canonical ) );

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'Canonical tag set for "' . $post->post_title . '"',
            'post_id' => $post->ID,
            'canonical' => $canonical,
        ] );
    }

    private static function fix_viewport( $request ) {
        $viewport = $request->get_param( 'viewport' ) ?: $request->get_param( 'content' );
        if ( empty( $viewport ) ) {
            $viewport = 'width=device-width, initial-scale=1';
        }

        update_option( 'signalor_viewport', $viewport );

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'Viewport meta tag set: ' . $viewport,
        ] );
    }

    private static function fix_noindex( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        // Yoast: set to '2' (index) instead of deleting
        if ( defined( 'WPSEO_VERSION' ) ) {
            update_post_meta( $post->ID, '_yoast_wpseo_meta-robots-noindex', '2' );
        }

        // RankMath: replace 'noindex' with 'index', preserve other directives
        if ( class_exists( 'RankMath' ) ) {
            $robots = get_post_meta( $post->ID, 'rank_math_robots', true );
            if ( ! is_array( $robots ) ) $robots = [];
            $robots = array_diff( $robots, [ 'noindex' ] );
            if ( ! in_array( 'index', $robots, true ) ) $robots[] = 'index';
            if ( ! in_array( 'follow', $robots, true ) ) $robots[] = 'follow';
            update_post_meta( $post->ID, 'rank_math_robots', array_values( $robots ) );
        }

        // AIOSEO
        if ( function_exists( 'aioseo' ) ) {
            update_post_meta( $post->ID, '_aioseo_noindex', false );
        }

        // Signalor fallback: force index via wp_head (only if no SEO plugin)
        if ( ! defined( 'WPSEO_VERSION' ) && ! class_exists( 'RankMath' ) && ! function_exists( 'aioseo' ) ) {
            update_post_meta( $post->ID, '_signalor_force_index', 'yes' );
        } else {
            // SEO plugin handles it — remove our override
            delete_post_meta( $post->ID, '_signalor_force_index' );
        }

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'Noindex removed for "' . $post->post_title . '" — page is now indexable',
            'post_id' => $post->ID,
        ] );
    }

    private static function fix_ai_meta( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        update_post_meta( $post->ID, '_signalor_ai_meta', 'yes' );

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'AI meta tags enabled for "' . $post->post_title . '"',
            'post_id' => $post->ID,
        ] );
    }

    // ── Element-level text replace (Content Optimisation) ─────────────

    public static function replace_text( $request ) {
        $post = self::find_post( $request );
        if ( is_wp_error( $post ) ) return $post;

        $find    = $request->get_param( 'find' );
        $replace = $request->get_param( 'replace' );

        if ( ! isset( $find ) || $find === '' || $replace === null ) {
            return new WP_Error( 'missing_params', 'find and replace are required.', [ 'status' => 400 ] );
        }

        $replaced = false;
        $source   = '';

        // HTML-entity encoded variant of the search term.
        // el.innerText returns decoded text (& not &amp;) but WordPress stores
        // HTML-encoded values in both post_content and _elementor_data.
        $find_enc    = htmlspecialchars( $find,    ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
        $replace_enc = htmlspecialchars( $replace, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );

        // JSON-escaped variant for Elementor's JSON data store.
        $find_json    = substr( json_encode( $find ),    1, -1 );
        $replace_json = substr( json_encode( $replace ), 1, -1 );

        // ── 1. post_content (Gutenberg, Classic Editor, Divi shortcodes) ──
        if ( strpos( $post->post_content, $find ) !== false ) {
            $new_content = str_replace( $find, $replace, $post->post_content );
            wp_update_post( [ 'ID' => $post->ID, 'post_content' => $new_content ] );
            $replaced = true;
            $source   = 'post_content';
        }

        // ── 2. post_content with HTML-encoded needle ──────────────────────
        if ( ! $replaced && $find_enc !== $find && strpos( $post->post_content, $find_enc ) !== false ) {
            $new_content = str_replace( $find_enc, $replace_enc, $post->post_content );
            wp_update_post( [ 'ID' => $post->ID, 'post_content' => $new_content ] );
            $replaced = true;
            $source   = 'post_content_encoded';
        }

        // ── 3. Elementor (_elementor_data JSON meta) ──────────────────────
        if ( ! $replaced ) {
            $elementor_raw = get_post_meta( $post->ID, '_elementor_data', true );
            if ( $elementor_raw ) {
                $new_elementor      = $elementor_raw;
                $found_in_elementor = false;

                if ( strpos( $elementor_raw, $find ) !== false ) {
                    $new_elementor      = str_replace( $find, $replace, $elementor_raw );
                    $found_in_elementor = true;
                    $source             = 'elementor_plain';
                } elseif ( $find_enc !== $find && strpos( $elementor_raw, $find_enc ) !== false ) {
                    $new_elementor      = str_replace( $find_enc, $replace_enc, $elementor_raw );
                    $found_in_elementor = true;
                    $source             = 'elementor_encoded';
                } elseif ( $find_json !== $find && strpos( $elementor_raw, $find_json ) !== false ) {
                    // Elementor encodes text values as JSON strings inside the JSON blob
                    $new_elementor      = str_replace( $find_json, $replace_json, $elementor_raw );
                    $found_in_elementor = true;
                    $source             = 'elementor_json';
                }

                if ( $found_in_elementor ) {
                    update_post_meta( $post->ID, '_elementor_data', wp_slash( $new_elementor ) );
                    // Clear Elementor's per-post CSS cache so the change renders immediately
                    delete_post_meta( $post->ID, '_elementor_css' );
                    if ( class_exists( '\Elementor\Plugin' ) ) {
                        \Elementor\Plugin::$instance->files_manager->clear_cache();
                    }
                    $replaced = true;
                }
            }
        }

        if ( ! $replaced ) {
            return new WP_Error(
                'text_not_found',
                'Could not locate that text in post_content or Elementor data.',
                [ 'status' => 422 ]
            );
        }

        return rest_ensure_response( [
            'status'  => 'success',
            'message' => 'Text replaced in "' . $post->post_title . '" (' . $source . ')',
            'post_id' => $post->ID,
            'url'     => get_permalink( $post->ID ),
            'source'  => $source,
        ] );
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private static function find_post( $request ) {
        // By ID
        $post_id = $request->get_param( 'post_id' );
        if ( $post_id ) {
            $post = get_post( intval( $post_id ) );
            if ( $post && $post->post_status === 'publish' ) return $post;
        }

        // By URL
        $url = $request->get_param( 'url' );
        if ( $url ) {
            $post_id = url_to_postid( $url );
            if ( $post_id ) {
                $post = get_post( $post_id );
                if ( $post && $post->post_status === 'publish' ) return $post;
            }

            // Slug fallback — single query across all public post types
            $path = wp_parse_url( $url, PHP_URL_PATH );
            $slug = trim( $path, '/' );
            $parts = explode( '/', $slug );
            $slug = urldecode( end( $parts ) );

            if ( $slug ) {
                $found = get_posts( [
                    'name'        => $slug,
                    'post_type'   => array_values( get_post_types( [ 'public' => true ] ) ),
                    'post_status' => 'publish',
                    'numberposts' => 1,
                ] );
                if ( $found ) return $found[0];
            }
        }

        return new WP_Error( 'post_not_found', 'Could not find the target post/page.', [ 'status' => 404 ] );
    }
}
