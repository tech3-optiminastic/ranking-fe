<?php
/**
 * Plugin Name: Signalor GEO
 * Plugin URI:  https://signalor.ai/wordpress
 * Description: Receive and apply GEO optimization fixes from Signalor.ai — schema, content, SEO meta, and llms.txt.
 * Version:     1.0.0
 * Author:      Signalor
 * Author URI:  https://signalor.ai
 * License:     GPL-2.0-or-later
 * Text Domain: signalor-geo
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SIGNALOR_VERSION', '1.0.0' );
define( 'SIGNALOR_PATH', plugin_dir_path( __FILE__ ) );

// Core classes
require_once SIGNALOR_PATH . 'includes/class-api.php';
require_once SIGNALOR_PATH . 'includes/class-schema.php';
require_once SIGNALOR_PATH . 'includes/class-llms.php';
require_once SIGNALOR_PATH . 'includes/class-admin.php';

// Boot
add_action( 'rest_api_init',     [ 'Signalor_API', 'register_routes' ] );
Signalor_Admin::register();
add_action( 'wp_head',           [ 'Signalor_Schema', 'render' ] );
add_action( 'init',              [ 'Signalor_LLMS', 'register_rewrite' ] );
add_action( 'template_redirect', [ 'Signalor_LLMS', 'serve' ] );

// SEO title filter (fallback when no SEO plugin installed)
add_filter( 'wp_title',          [ 'Signalor_Schema', 'filter_title' ] );
add_filter( 'pre_get_document_title', [ 'Signalor_Schema', 'filter_title' ] );

// Prevent trailing slash redirect on /llms.txt
add_filter( 'redirect_canonical', function ( $redirect_url, $requested_url ) {
    if ( preg_match( '/\/llms\.txt\/?$/', $requested_url ) ) return false;
    return $redirect_url;
}, 10, 2 );

// robots.txt filter — allow AI bots
add_filter( 'robots_txt', function ( $output, $public ) {
    $custom = get_option( 'signalor_robots_txt', '' );
    if ( ! empty( $custom ) ) {
        // Merge: keep existing output, append custom rules
        // Don't replace entirely — preserve WordPress core rules
        return $output . "\n" . $custom;
    }

    // Default: ensure AI bots are allowed
    $ai_bots = [ 'GPTBot', 'Google-Extended', 'anthropic-ai', 'ClaudeBot', 'PerplexityBot', 'ChatGPT-User', 'CCBot' ];
    $additions = "\n# Signalor GEO — Allow AI crawlers\n";
    foreach ( $ai_bots as $bot ) {
        if ( stripos( $output, $bot ) === false ) {
            $additions .= "User-agent: {$bot}\nAllow: /\n\n";
        }
    }
    return $output . $additions;
}, 10, 2 );

// On activation: generate API key + flush rewrite rules
register_activation_hook( __FILE__, function () {
    if ( ! get_option( 'signalor_api_key' ) ) {
        update_option( 'signalor_api_key', wp_generate_password( 40, false ) );
    }
    Signalor_LLMS::register_rewrite();
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, function () {
    flush_rewrite_rules();
} );
