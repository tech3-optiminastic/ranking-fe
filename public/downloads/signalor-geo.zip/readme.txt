=== Signalor GEO ===
Contributors: signalor
Tags: seo, geo, ai, schema, llms, chatgpt, gemini, perplexity, claude, visibility
Requires at least: 5.6
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Optimize your WordPress site for AI search engines — ChatGPT, Gemini, Perplexity, and Claude.

== Description ==

Signalor GEO is a companion plugin for [Signalor.ai](https://signalor.ai) — the AI visibility and GEO (Generative Engine Optimization) analysis platform.

This plugin receives approved fixes from the Signalor dashboard and applies them to your site automatically:

* **Content optimization** — adds citations, FAQ sections, expert quotes, statistics
* **JSON-LD schema** — injects structured data (Organization, Article, FAQ, Product)
* **SEO meta tags** — updates title and description (Yoast, RankMath, AIOSEO compatible)
* **llms.txt** — creates and serves /llms.txt for AI crawlers
* **robots.txt** — adds AI bot allow rules (GPTBot, ClaudeBot, etc.)
* **AI meta tags** — adds AI crawler directives via wp_head
* **Canonical URLs** — sets canonical tags (removes duplicates from SEO plugins)
* **Viewport** — sets responsive viewport meta tag
* **Noindex removal** — forces indexing (works with Yoast, RankMath, AIOSEO)

= How it works =

1. Install and activate this plugin
2. Connect your site from the Signalor dashboard
3. Run a GEO analysis on signalor.ai
4. Review recommendations and preview fixes
5. Approve a fix — the plugin applies it to your site automatically
6. Re-analyze to see your improved AI visibility score

= SEO Plugin Compatibility =

Works alongside your existing SEO plugin:

* **Yoast SEO** — writes to Yoast meta fields, disables duplicate schema/canonical
* **RankMath** — writes to RankMath meta fields, preserves robot directives
* **AIOSEO** — writes to AIOSEO meta fields
* **No SEO plugin** — renders its own meta tags as fallback

= Security =

* All API endpoints authenticated via unique API key (auto-generated on activation)
* API key verified with timing-safe comparison (hash_equals)
* Content sanitized with wp_kses_post before saving
* Original content backed up before overwriting

== Installation ==

1. Upload the `signalor-wordpress-plugin` folder to `/wp-content/plugins/`
2. Activate the plugin through the Plugins menu
3. Go to your Signalor dashboard → Settings → Integrations → WordPress
4. Enter your site URL — the plugin is auto-discovered

Or install from the WordPress Plugin Directory:
1. Go to Plugins → Add New → search "Signalor GEO"
2. Click Install → Activate

== Frequently Asked Questions ==

= Do I need a Signalor account? =
Yes, this plugin works with [signalor.ai](https://signalor.ai). Sign up for free to run your first analysis.

= Does it work with Yoast/RankMath? =
Yes. The plugin detects your active SEO plugin and writes to the correct meta fields. It also prevents duplicate schema and canonical tags.

= What is llms.txt? =
llms.txt is an emerging standard (like robots.txt) that tells AI models what your site is about. The plugin serves it at /llms.txt as plain text.

= Is my content safe? =
Yes. The plugin backs up original content before applying fixes. All content is sanitized. Fixes are previewed before you approve them in the Signalor dashboard.

== Changelog ==

= 1.0.0 =
* Initial release
* 10 fix types: content, faq, schema, meta, llms, robots, canonical, viewport, noindex, ai_meta
* JSON-LD injection via wp_head with SEO plugin conflict handling
* Virtual /llms.txt with auto-generated fallback content
* AI bot allow rules in robots.txt
* Yoast, RankMath, and AIOSEO compatibility
* Content backup before overwriting
